package org.hdcd.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HomeController {
	@RequestMapping(value="/")
    public String home() {
        return "home";  // index.html or index.jsp
    }
	
	@RequestMapping(value="/formHome")
    public String fromHome() {
        return "formHome";  
    }
	
	@RequestMapping(value="/ajaxHome")
	public String ajaxHome() {
		return "ajaxHome";
	}
	
	@GetMapping("/goHome0101")
	public void home0101() {
		log.info("home0101");
	}
	
	@GetMapping("/sub/goHome0102")
	public void home0102() {
		log.info("goHome0102");
	}
}

