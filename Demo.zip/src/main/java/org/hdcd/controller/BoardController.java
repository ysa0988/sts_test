package org.hdcd.controller;

import java.time.LocalDateTime;

import org.hdcd.domain.Board;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;


@Slf4j
@Controller
@RequestMapping("/board")
public class BoardController {
	
	@GetMapping("/{boardNo}")
	public ResponseEntity<Board> read(@PathVariable("boardNo") int boardNo) {
		log.info("read");
		Board board = new Board();
		board.setBoardNo(boardNo);
		board.setTitle("제목");
		board.setContent("내용");
		board.setWriter("홍길동");
		board.setRegDate(LocalDateTime.now());
		ResponseEntity<Board> entity = new ResponseEntity<Board>(board, HttpStatus.OK);
		return entity;
	}
	
	@GetMapping(path="/{boardNo}", produces="application/json")
	public ResponseEntity<Board> readToJson(@PathVariable("boardNo") int boardNo) {
		log.info("readToJson");
		Board board1 = new Board();
		board1.setBoardNo(boardNo);
		board1.setTitle("json타이틀");
		board1.setContent("json내용");
		board1.setWriter("양선아");
		board1.setRegDate(LocalDateTime.now());
		ResponseEntity<Board> entity = new ResponseEntity<Board>(board1, HttpStatus.OK);
		return entity;
	}
	
	@GetMapping(path="/{boardNo}", produces="application/xml")
	public ResponseEntity<Board> readToXml (@PathVariable("boardNo") int boardNo) {
		log.info("readToXml");
		Board board2 = new Board();
		board2.setBoardNo(boardNo);
		board2.setTitle("xml타이틀");
		board2.setContent("xml내용");
		board2.setWriter("강병렬");
		board2.setRegDate(LocalDateTime.now());
		ResponseEntity<Board> entity = new ResponseEntity<Board>(board2, HttpStatus.OK);
		return entity;
	}

	@GetMapping(path="/get", params="register")
	public String registerForm() {
		log.info("registerForm");
		return "board/register";
	}
	
	@PostMapping(path="/post", params="register")
	public String register() {
		log.info("refister");
		return "board/list";
	}
	
	@GetMapping(path="/get", params="modify")
	public String modifyForm() {
		log.info("modifyForm");
		return "board/modify";
	}
	
	@PostMapping(path="/post", params="modify")
	public String modify() {
		log.info("modify");
		return "body/list";
	}
	
	@GetMapping(path="get", params="remove")
	public String removeForm() {
		log.info("removeForm");
		return "board/remove";
	}
	
	@PostMapping(path="/post", params="remove")
	public String remove() {
		log.info("remove");
		return "board/list";
	}
	
	@GetMapping(path="/get", params="list")
	public String list() {
		log.info("list");
		return "board/list";
	}
	
	@GetMapping(path="/get", params="read")
	public String read() {
		log.info("read");
		return "board/read";
	}

	
}
